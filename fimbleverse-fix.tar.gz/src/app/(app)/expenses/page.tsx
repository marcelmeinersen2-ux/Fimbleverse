import { redirect } from 'next/navigation';
import { createClient } from '@/lib/database/server';
import { getHouseholdContext } from '@/lib/auth/session';
import { fetchMembers } from '@/features/household/members';
import { AddExpenseForm } from '@/features/expenses/components/AddExpenseForm';
import { zloty, shortDate } from '@/lib/utils/format';

function one<T>(v: T | T[] | null | undefined): T | undefined {
  return Array.isArray(v) ? v[0] : v ?? undefined;
}

interface ExpenseRow {
  id: string;
  amount: number;
  spent_on: string;
  description: string;
  expense_categories: { name: string } | { name: string }[] | null;
  profiles: { display_name: string } | { display_name: string }[] | null;
}

export default async function ExpensesPage() {
  const ctx = await getHouseholdContext();
  if (!ctx) redirect('/onboarding');
  const supabase = createClient();

  const [{ data: categories }, people, { data: expensesData }] = await Promise.all([
    supabase.from('expense_categories').select('id, name')
      .eq('household_id', ctx.householdId).order('sort_order'),
    fetchMembers(supabase, ctx.householdId),
    supabase.from('expenses')
      .select('id, amount, spent_on, description, expense_categories(name), profiles:payer_id(display_name)')
      .eq('household_id', ctx.householdId)
      .order('spent_on', { ascending: false })
      .limit(50),
  ]);

  const cats = (categories ?? []) as { id: string; name: string }[];
  const expenses = (expensesData ?? []) as unknown as ExpenseRow[];
  const today = new Date().toISOString().slice(0, 10);

  return (
    <section className="space-y-8">
      <div>
        <h1 className="font-display text-2xl">Expenses</h1>
        <p className="mt-1 text-sm text-muted">Everything you both spend, in one place.</p>
      </div>

      <AddExpenseForm categories={cats} people={people} today={today} />

      <div>
        <h2 className="text-sm font-medium text-muted mb-3">Recent</h2>
        {expenses.length === 0 ? (
          <p className="text-muted text-sm rounded-card border border-line bg-surface p-6">
            No expenses yet. Add your first one above and it’ll show up here.
          </p>
        ) : (
          <ul className="space-y-2">
            {expenses.map((e) => {
              const category = one(e.expense_categories)?.name ?? '';
              const payer = one(e.profiles)?.display_name ?? '';
              return (
                <li key={e.id}
                  className="rounded-card bg-surface border border-line px-4 py-3 flex items-baseline justify-between">
                  <div>
                    <p className="text-ink">{e.description || category}</p>
                    <p className="text-xs text-muted">
                      {shortDate(e.spent_on)} · {category} · {payer}
                    </p>
                  </div>
                  <span className="font-medium tabular-nums">{zloty(Number(e.amount))}</span>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </section>
  );
}
