import { redirect } from 'next/navigation';
import { getHouseholdContext } from '@/lib/auth/session';

export default async function Home() {
  const ctx = await getHouseholdContext();
  redirect(ctx ? '/expenses' : '/login');
}
