'use client';
import { useState } from 'react';
import { createClient } from '@/lib/database/client';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithOtp({
      email, options: { emailRedirectTo: `${location.origin}/` },
    });
    if (error) { setError("We couldn't send the link. Check the address and try again."); return; }
    setSent(true);
  }

  return (
    <main className="min-h-screen mx-auto max-w-md px-5 flex flex-col justify-center">
      <h1 className="font-display text-3xl">Welcome to Fimbleverse</h1>
      <p className="mt-2 text-muted">A calm shared view of home life.</p>
      {sent ? (
        <p className="mt-8 rounded-card bg-surface border border-line p-6">
          Check your email for a sign-in link.
        </p>
      ) : (
        <form onSubmit={signIn} className="mt-8 space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm text-muted mb-1">Email</label>
            <input id="email" type="email" required value={email}
              onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com"
              className="w-full rounded-control border border-line px-3 py-2 bg-surface" />
          </div>
          {error && <p role="alert" className="text-sm text-danger">{error}</p>}
          <button type="submit"
            className="w-full rounded-control bg-primary text-primary-ink font-medium py-3">
            Send sign-in link
          </button>
        </form>
      )}
    </main>
  );
}
