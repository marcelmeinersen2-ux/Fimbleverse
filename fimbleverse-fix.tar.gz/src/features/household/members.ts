// Shared shape + fetch for household members with their display name.
// We type the result explicitly rather than relying on Supabase's inferred
// type for the joined select, which can collapse to `never` under strict
// builds. One place, reused by balance / expenses / settings.
import type { SupabaseClient } from '@supabase/supabase-js';

export interface Member {
  id: string;
  role: 'member' | 'admin';
  name: string;
}

interface MemberRow {
  user_id: string;
  role: 'member' | 'admin';
  profiles: { display_name: string } | { display_name: string }[] | null;
}

function displayName(p: MemberRow['profiles']): string {
  if (!p) return 'Someone';
  const row = Array.isArray(p) ? p[0] : p;
  return row?.display_name ?? 'Someone';
}

export async function fetchMembers(
  supabase: SupabaseClient,
  householdId: string,
): Promise<Member[]> {
  const { data } = await supabase
    .from('household_members')
    .select('user_id, role, profiles(display_name)')
    .eq('household_id', householdId);

  const rows = (data ?? []) as unknown as MemberRow[];
  return rows.map((m) => ({
    id: m.user_id,
    role: m.role,
    name: displayName(m.profiles),
  }));
}
